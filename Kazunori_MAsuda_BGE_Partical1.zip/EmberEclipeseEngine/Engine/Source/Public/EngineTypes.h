#pragma once
#include <iostream>
#include<vector>

using namespace std;

template<typename T>
using TArray = vector<T>;