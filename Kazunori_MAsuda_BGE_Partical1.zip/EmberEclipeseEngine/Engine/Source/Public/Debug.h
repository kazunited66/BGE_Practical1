#pragma once
#include<iostream>
using namespace std;
//Logs a message to the console
#define EE_LOG(cn,msg) cout<<cn<<" | " << msg <<endl